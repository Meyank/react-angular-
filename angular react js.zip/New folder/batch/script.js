var batches ={
    batch:[],

    add:function(batchToAdd,dateToAdd){
        this.batch.push({
            newBatch:batchToAdd,newDate:dateToAdd
        });
    },
    delete:function(positionToDelete){
          console.log("in batches   "+positionToDelete);
      this.batch.splice(positionToDelete,1);
      
    },
       edit:function(position,newValue,updatedDate){
        this.batch[position].newBatch=newValue;
             this.batch[position].newDate=updatedDate;
  },
    
}



var handler={

    add:function(){
     var batchToAdd= document.getElementById("inputTextbox"); 
     var dateToAdd= document.getElementById("inputDate"); 
        console.log(dateToAdd.value);
        batches.add(batchToAdd.value,dateToAdd.value);
        dateToAdd.value="";
        batchToAdd.value="";
        view.display();
        
     },
    
    delete:function(positionToDelete){
        console.log("in handler    "+positionToDelete);
        batches.delete(positionToDelete);
        
    },
    edit:function(positionToEdit){
        console.log("in handler  "+positionToEdit);
        
    var elementToEdit = document.getElementById("positionToEdit");
        
    console.log(elementToEdit);
        
        
        
        
        
        
        
        batches.edit(positionToEdit);
       
        
    }
    
    
    }



var view={
    display:function(){
          for(var i=0;i<batches.batch.length;i++){
              
              var ul = document.querySelector('ul');
                
               var li=    document.createElement('li');
              
              
              
               var deletebutton=document.createElement('button');
            
              deletebutton.textContent="X";
            deletebutton.className="deletebutton";
             deletebutton.setAttribute('onclick', 'handler.delete('+i+')' );
              
              
              
               
               var editButton=document.createElement('button');
            
              editButton.textContent="edit";
            editButton.className="editButton";
             editButton.setAttribute('onclick', 'handler.edit('+i+')');
              
              
              
              
                
             var label =  document.createElement('label'); 
              
              label.textContent = batches.batch[i].newDate;
              
               var label1 =  document.createElement('label'); 
              
              label1.textContent = batches.batch[i].newBatch;
              
              
//               label1.contentEditable = true;
//               label.contentEditable = true;
             
              li.appendChild(deletebutton);
              
              li.appendChild(editButton);
              
            
             li.appendChild(label1);
               li.appendChild(label);
               ul.appendChild(li);
              
              
          }
    }
}