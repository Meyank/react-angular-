import React, { Component } from 'react';
import ListToDo from './listToDo';
import FormComponent from './formComponent';
class MainComponent extends Component{

    constructor(){
        super();
        this.state={

            todos:[
                   {todoText:'how are you', completed: false},
                   {todoText:'where are you from', completed: false}

            ],
            currentTodo: ""
    }
    
        
    }

     handleToggle= (index) =>{
        //  console.log(index);
         let todos = this.state.todos;
         let todo = todos[index];
         
         todo.completed=!todo.completed;
  
        this.setState({
          todos:todos }
        );


         

     }


     handleSubmit=(currentTodo)=>{

        this.setState({
           todos: this.state.todos.concat( {todoText: currentTodo,completed: false} )
        })
         
       
     }
     handleEdit=(toEdit,index)=>{
       
        let todos=this.state.todos;
        let todoToUpdate =todos[index];
        todoToUpdate = toEdit;
        this.setState({
          todos

        })


    


      console.log(toEdit,index);
     }


     handleDelete=(key)=>{
 
        let todos = this.state.todos;
        
             todos.splice(key,1);
        console.log("handle main",key);
        this.setState({
            // temp:this.state.todos.splice(key,1),
            todos
        })
         
     }

    render(){
        return(

            <div >
        
         <FormComponent   submit={this.handleSubmit}  currentTodo={this.state.currentTodo}/>

                <ul>
           {
                    this.state.todos.map((todo,index) => {
                         
                      return  (<ListToDo key={index} update={this.handleEdit}
                        delete={this.handleDelete} mykey={index} click={this.handleToggle} todo={todo} />);
                    })
                }
                

          
           
           </ul>
        </div>
        );
    }
}
export default MainComponent;