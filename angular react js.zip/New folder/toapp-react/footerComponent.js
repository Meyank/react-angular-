import React, { Component } from 'react';

class FooterComponent extends Component{

    render(){
        return(
            <div className="footer">
            Developed By Mayank
        </div>
        );
    }
}
export default FooterComponent;