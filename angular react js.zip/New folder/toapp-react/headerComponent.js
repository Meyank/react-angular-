import React, { Component } from 'react';
import AppBar from 'material-ui/AppBar';
import RaisedButton from 'material-ui/RaisedButton';
import FontIcon from 'material-ui/FontIcon';
import IconButton from 'material-ui/IconButton';
// import FormComponent from './formComponent';

import Popover from 'material-ui/Popover';
import Menu from 'material-ui/Menu';
import MenuItem from 'material-ui/MenuItem';

class HeaderComponent extends Component {
    constructor(props) {
        super(props);

        this.state = {
            open: false,
            showForm:false
        };
    }

    handleClick = (event) => {
        // This prevents ghost click.

       
        event.preventDefault();
       
        this.setState({
            open: true,
            anchorEl: event.currentTarget,
        });
    };

    handleForm = (event) => {
    event.preventDefault();
    console.log("in handleform ");
    
    this.setState({
      showForm:true
    });

    

    };

    handleRequestClose = () => {
        this.setState({
            open: false,
        });
    };





    render() {
        return (
            <div>
              
                <Popover
                    open={this.state.open}
                    anchorEl={this.state.anchorEl}
                    anchorOrigin={{ horizontal: 'left', vertical: 'bottom' }}
                    targetOrigin={{ horizontal: 'left', vertical: 'top' }}
                    onRequestClose={this.handleRequestClose}
                >
                    <Menu>
                        <MenuItem primaryText="Add-New" onClick={this.handleForm} />
                        <MenuItem primaryText="Delete" />
                        <MenuItem primaryText="Update" />
                        <MenuItem primaryText="Referesh " />
                    </Menu>
                </Popover>

                <AppBar
                    title="My-ToDo App"
                    iconElementLeft={
                        <IconButton>
                            <FontIcon
                                className="material-icons" onClick={this.handleClick}>view_headline</FontIcon>
                        </IconButton>
                    }
                     
                    iconElementRight={
                        // <RaisedButton label="Primary" primary={true}  />
                        <IconButton>
                            <FontIcon
                                className="material-icons">settings</FontIcon>
                        </IconButton>
                           
                    }
                   

                />
                {/* <FormComponent order={this.state.showForm===true?'show':'dontShoW'}/> */}
            </div>

        );
    }
}
export default HeaderComponent;