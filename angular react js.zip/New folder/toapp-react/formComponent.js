import React from 'react';
import TextField from 'material-ui/TextField';
import FloatingActionButton from 'material-ui/FloatingActionButton';
import ContentAdd from 'material-ui/svg-icons/content/add';

class FormComponent extends React.Component{

 state= {
   currentTodo:''
 }

 
  updateTodo=(event)=>{
   
    this.setState({
      currentTodo:event.target.value
    })
  }




  
  handleSubmit=(event)=>{
    
   event.preventDefault();
    this.props.submit(this.state.currentTodo);
   
  }
 
    render () {
        console.log();

        return(

          // <div className={this.props.order} >
          <div>
   <form onSubmit= {this.handleSubmit}>
   <TextField 
      hintText="Enter Your To-Do Text"  onChange={this.updateTodo}
    />
          
    <FloatingActionButton type ="submit" mini={true} style={{ marginRight: 20}}>
      <ContentAdd />
    </FloatingActionButton>
     
           
</form>
          </div>
          

        );
    }
}
export default FormComponent;