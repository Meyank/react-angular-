import React, { Component } from 'react';

class ListToDo extends Component{
    




    
    delete=()=>{
        console.log("listtodo");
        this.props.delete(this.props.mykey);
    }
    toggle=()=>{
        
    this.props.click(this.props.mykey)
    }


    handleEditButton=(event)=>{
       
    let id =event.target.id;

//  console.log(event.target.id);

    
        document.getElementById(id).contentEditable="true";
       
     
         
    }

 handleEdit=(event)=>{
      
    if(event.key === 'Enter') {
        this.props.update(event.target.innerHTML,this.props.mykey);
      

        
    }
    
 }
    
    
render(){
    return(
        <div>
       
    <li  onDoubleClick={()=>{this.toggle()}} className={this.props.todo.completed===true?'completed':''} >
      {this.props.mykey} &nbsp;
      <span id={this.props.mykey} onKeyPress={this.handleEdit}> {this.props.todo.todoText} </span>
     
       
      <button id={this.props.mykey}   onClick={this.handleEditButton}>E</button>
        
        <button className="deleteButton" onClick={this.delete}>X</button>
       
        
         </li>
        
        </div>
    );
}

}
export default ListToDo ;