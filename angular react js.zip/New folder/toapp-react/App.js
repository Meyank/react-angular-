import React, { Component } from 'react';
import logo from './logo.svg';
import HeaderComponent from './headerComponent';
import MainComponent from './mainComponent';
import FooterComponent from './footerComponent';
import './App.css';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';

class App extends Component {
  render() {
    return (
    

<MuiThemeProvider>
   <div>

       <HeaderComponent></HeaderComponent>

       <MainComponent ></MainComponent>

       <FooterComponent></FooterComponent>
     </div>
  </MuiThemeProvider>
  
    );
  }
}

export default App;
