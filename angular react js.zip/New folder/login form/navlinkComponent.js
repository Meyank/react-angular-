import React from 'react';
import { Link, NavLink, Redirect } from 'react-router-dom';



class NavigationComponent extends React.Component {

    redirect = () => {
        console.log("hiih");
        <Redirect to='/welcome' />
    }

    render() {

        return (
            <div>
                <NavLink to="/about" activeClassName="clicked" >About</NavLink>
                <button onClick={this.redirect}>Redirect</button>
            </div>
        )
    }
}
export default NavigationComponent;