import React from 'react';


const WelcomeComponent = () => {

    return (
        <div><h1>Welcome</h1>
        </div>
    )

}
export default WelcomeComponent;