import React from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import AboutComponent from './aboutComponent';
import WelcomeComponent from './welcomeComponent';
import NavigationComponent from './navlinkComponent';


const RouterComponent = () => {


    return (

        <Router>
         <div>

                <NavigationComponent />

         
            <Route path="/welcome" component={WelcomeComponent}/>        
            <Route exact path="/about" component={AboutComponent} />
</div>
        </Router>


    );

}
export default RouterComponent;
