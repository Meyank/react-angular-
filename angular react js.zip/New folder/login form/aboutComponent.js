import React from 'react';
import { Navi } from 'react-router-dom';

const AboutComponent =()=>{


 return(
<div>
    
    
     <h1>  About</h1>
     
    </div>

 );

}
export default AboutComponent;
