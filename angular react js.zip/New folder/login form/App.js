import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import { Provider } from 'react-redux';
import { createStore } from 'redux';
import Count from './count';


//declaring state
const initialState = {
  count: 50
}

//declare reduce which will take input state and action in reducer which will pass the data store
function myReducer(state = initialState, action) {
  // return({
  //   count:50
  // })


  if (action.type === 'increment') {
    console.log("called");
    
    return {count: state.count + 1
  }}
  return state;
}

// store to create a global store that will be available for all component
const store = createStore(myReducer);


const App = () => {
  return (

    // provider to pass the store to every component 
    <Provider store={store}>

      
        <Count> </Count>
      
    </Provider>
  );
}


export default App;
