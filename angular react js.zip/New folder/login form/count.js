import React from 'react';
import {connect} from 'react-redux';

class Count extends React.Component {


increment=()=>{
  console.log("incerememrme in count");
  //calling the increment method
        this.props.dispatch({type:"increment"});
  
}

render() {
    return(
        
        <div>
        <span> {this.props.count}</span>
        <button onClick={this.increment}>+</button>
         
        
        
        </div>
    );
}


}

//this is to map the global state which is given here by provider
// here mapping the porps value count to global store count
function mapStateToProps(state){

 return{
     count:state.count
 }
}

//connecting this component to global store
export  default connect(mapStateToProps)(Count);