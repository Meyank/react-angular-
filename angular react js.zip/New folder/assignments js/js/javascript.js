var asmt={
   assmt:[],
  
    add:function(addAssignments){
      this.assmt.push({
          assmtt:addAssignments,completed:false}
                ) ; 
    },
    
    
    edit:function(position,newValue){
        this.assmt[position].assmtt=newValue;
  },
      delete:function(position){
      this.assmt.splice(position,1);
        
      },
       toggle:function(position){
  this.assmt[position].completed=!this.assmt[position].completed;
       
},
   
    toggleall:function(){
       var completed=0;
     var  totallength=this.assmt.length;
        for(var i=0;i<totallength ;i++){
            if(this.assmt[i].completed==true)
            completed++;
                   
        }
        
        
        if(totallength==completed){
        for( i=0;i<this.assmt.length;i++){
           this.assmt[i].completed=false;
           
        }
         
        }
        else{
            for( i=0;i<this.assmt.length;i++){
            this.assmt[i].completed=true;         
        } }  } };





var handler={
display:function(){
  view.display();  
},
    add:function(key){
        if(key.keyCode==13){
      var addAssignments=document.getElementById("inputTextbox"); 
        asmt.add(addAssignments.value);
        addAssignments.value="";
        view.display(); }
    },
    edit:function(){
     var position=document.getElementById("position");
     var newText=document.getElementById("newinputTextbox");
        asmt.edit(position.value,newText.value);
        view.display(); 
    },   
    toggle:function(position){
//      var position=document.getElementById("positiontoggle");
        var pos=parseInt(position);
       asmt.toggle(pos);
        view.display(); 
},
    delete:function(position){
//       var position=document.getElementById("positionDelete");
       asmt.delete(position.valueAsNumber); 
        view.display(); 
    },
    toggleall:function(){
        
        asmt.toggleall();
        view.display(); 
    }
    

};







var view={
    display:function(){
     var ul = document.querySelector('ul');
        
      
    
        ul.innerHTML='';

      

        
        for(var i=0;i<asmt.assmt.length;i++){
             var checkbox = document.createElement('input');
            checkbox.type='checkbox';
            var li=    document.createElement('li');
          var status = asmt.assmt[i].completed;
            if(status===true){
                checkbox.setAttribute('checked',true);
                li.className="checked";
//                 completed= '(x)  ' + asmt.assmt[i].assmtt;   
            }
            else{
                checkbox.setAttribute('unchecked',true);
                 li.className="uncheckedtoggle";
//                completed= '()  ' + asmt.assmt[i].assmtt;   
            }
            
            
            var deletebutton=document.createElement('button');
            
              deletebutton.textContent="X";
            deletebutton.className="deletebutton";
             deletebutton.setAttribute('onclick', 'handler.delete('+i+')' );
            
//        var    divforlitext =document.createElement('div');
//            divforlitext.className="divforlitext";
            
            checkbox.className="checkbox";
         
            
             
           checkbox.setAttribute('onchange','handler.toggle('+i+')');
            
             
            li.textContent=asmt.assmt[i].assmtt;   
            
//        li.appendChild(divforlitext);
           
         li.appendChild(deletebutton);
            li.appendChild(checkbox);
            
            ul.appendChild(li);
        }}  };






                                   
