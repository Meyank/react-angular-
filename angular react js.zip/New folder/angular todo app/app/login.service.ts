import { Injectable } from '@angular/core';
import {Http, Headers, Response} from '@angular/http';
import {Observable}     from 'rxjs/Observable';
import { User } from './user';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class LoginService {

  
  constructor (private http: Http) {}

  sendCredential(loginname: string, password: string) {

    // let param = "loginname"+loginname+"password"+password;


    let url = 'http://localhost:8080/issue-web/user/login';
    var user={ "loginname":loginname,"password":password };
    let headers = new Headers(
    {  
      // 'Content-Type': 'application/x-www-form-urlencoded'
      'Content-Type': 'application/json'
     });
   
    return this.http.post(url, user, {headers: headers, withCredentials : true});
  }


  getUsers(): Observable<Object[]>{

       let url = "http://localhost:8080/issue-web/issues/1";
     return this.http.get(url).map(this.extractData);

  }
  
  private extractData(res: Response) {
    console.log(res);
    let body = res.json();
    
    console.log(body);
          return body;
      }

 
      

      getImage(filename:String):Observable<any> {

        let url = "http://localhost:8080/issue-web/images";
        return this.http.get(url)
          .map(this.extractUrl)
         
      }
      extractUrl(res:Response):string {
        return res.url;
      }

}