import { Hero } from './hero';

export const HEROES : Hero[] = [
   { id: 1 , name: 'batman'   },
   { id: 2,  name : 'superman' },
   { id: 3 , name: 'kingsman'   },
   { id: 4 , name: 'doraemon'   },
]