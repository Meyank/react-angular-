export class User {
    id: Number;
    name: string;
  }