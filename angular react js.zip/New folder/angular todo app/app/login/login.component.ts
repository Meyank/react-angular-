import { Component, OnInit } from '@angular/core';
import {Observable}  from 'rxjs/Observable';
import {LoginService} from '../login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  username: string;
  password: string;


   msg:String;

  loggedInUser: Object;
  issues : Object[];
  constructor(private loginService: LoginService) { }

  ngOnInit() {
  }

  onSubmit() {
  	this.loginService.sendCredential(this.username, this.password).subscribe(
      
      res => {
        //for object ftom controller 

          this.loggedInUser = JSON.parse(JSON.parse(JSON.stringify(res))._body) ; 
       
          // for string response from controller 

        //  console.log(res.text());
       // this.msg = JSON.parse(JSON.parse(JSON.stringify(res))._body); 
          
        
        console.log(this.loggedInUser);
        
      },
      err => {
        console.log(err);
       
    }
    );
  }

  getUser(){
    this.loginService.getUsers().subscribe(
      

      users => this.issues = users
     


    );
  }
  image:string;

  showImage(filename:string) {
    this.loginService.getImage(filename)
      .subscribe((file) => {
          this.image = file;
        });
      }

}
