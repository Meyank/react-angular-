import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from "@angular/router";
import { UserService } from '../user.service';
import { Observable } from 'rxjs/Observable';
import { IssueService } from '../issue.service';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {


   loggedInUser:object;

   id:Number = 1;
   issues : Object[];

  public constructor(private userService:UserService,private issueService:IssueService) {
    
    this.getUser();
   
}
  ngOnInit() {
    
    
    
    //  this.getIssues(this.id);
     
  }

  getUser(){
    this.loggedInUser=this.userService.user;
    // this.id = this.loggedInUser['id'];
  }
 

//to call service method on the basis of userId
  getIssues(id){
   
  this.issueService.getIssues(id).subscribe(
    

  
  issues =>this.issues=issues
  

   


  );
}






}
