import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import{ HttpModule } from '@angular/http'
import { LoginService } from './login.service';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { AppRoutingModule } from './app-routing.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UserService } from './user.service';
import { IssueService } from './issue.service';


@NgModule

({
  
  declarations: [
   
    AppComponent,
    LoginComponent,
    DashboardComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpModule
 
  ],
  providers: [LoginService, UserService,IssueService],
  bootstrap: [AppComponent]
})
export class AppModule { }
