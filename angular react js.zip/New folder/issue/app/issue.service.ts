import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import {Http, Headers, Response} from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class IssueService {
  
  

  constructor(private http:Http) { }




  getIssues(id:Number): Observable<Object[]>{
    console.log(id);
           let url = "http://localhost:8080/issue-web/issues/"+id;
         return this.http.get(url).map(this.extractData);
    
      }
      
      private extractData(res: Response) {
        console.log(res);
        let body = res.json();
        
        console.log(body);
              return body;
          }


}
