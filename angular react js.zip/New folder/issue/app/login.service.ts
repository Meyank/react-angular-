import { Injectable } from '@angular/core';
import { LoginComponent } from './login/login.component';
import {Http, Headers, Response} from '@angular/http';

import {Observable}     from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';


@Injectable()
export class LoginService {

  constructor(private http:Http) { }


sendCredential(loginname: string, password: string) {
        // let param = "loginname"+loginname+"password"+password;
         let url = 'http://localhost:8080/issue-web/user/login';
      var user={ "loginname":loginname,"password":password };
      let headers = new Headers(
      {  
        // 'Content-Type': 'application/x-www-form-urlencoded'
        'Content-Type': 'application/json'
       });
     
      return this.http.post(url, user, {headers: headers, withCredentials : true});
    }
  }