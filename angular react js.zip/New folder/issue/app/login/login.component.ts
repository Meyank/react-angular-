import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';
import { Router, NavigationExtras } from '@angular/router'
import { UserService } from '../user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})


export class LoginComponent implements OnInit {


username: string;
password: string;
loggedInUser: object;
loginFailed: boolean;
loggedIn : boolean;


  constructor(private router: Router , private loginService : LoginService,
  private userService:UserService) { 
    if(localStorage.getItem('UserHasLoggedIn') == '' || localStorage.getItem('UserHasLoggedIn') == null) {
      this.loggedIn = false;
    } else {
      this.loggedIn = true;
    }
  }




  ngOnInit() {
  }

  onSubmit() {
  	this.loginService.sendCredential(this.username, this.password).subscribe(
      
      res => {
        //for object ftom controller 
          this.loggedInUser = JSON.parse(JSON.parse(JSON.stringify(res))._body) ; 
   
          // for string response from controller 
        //  console.log(res.text());
       // this.msg = JSON.parse(JSON.parse(JSON.stringify(res))._body); 
         console.log(this.loggedInUser);

         // check to set user is logged i nor not  
         localStorage.setItem('UserHasLoggedIn', 'true');

         //storing logged in user in querry to pass it to other component 
         this.userService.user=this.loggedInUser;
         
         this.router.navigate(['/dashboard']);

        
      },
      err => {
       this.loginFailed = true;
        console.log(err);
       
    }
    );
  }


}
