function genricFun(argument) {
    var arayOfT = [];
    arayOfT.push(argument);
    return arayOfT;
}
var arayOfString = genricFun("mayank");
console.log(arayOfString);
console.log(typeof (arayOfString));
var arayOfInt = genricFun(42454);
console.log(arayOfInt);
console.log(typeof (arayOfInt));
