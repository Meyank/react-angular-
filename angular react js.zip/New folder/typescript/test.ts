function genricFun<T>(argument: T):T[]{
    
var arayOfT : T[] = [] ;
arayOfT.push(argument);
return arayOfT;

}

var arayOfString = genricFun<String>("mayank");
console.log(arayOfString);
console.log(typeof(arayOfString));


var arayOfInt = genricFun(42454);
console.log(arayOfInt);
console.log(typeof(arayOfInt));