var view ={ 
    dsiplay:function(){
//    var div = document.querySelector('div');
        
        
     var div=   document.getElementById('d');
      
        console.log(div);
    var button = document.createElement('button');
    button.textContent="click me ";
     this.render(button,div);
        
    
},
    render:function(what,where){
        
       where.appendChild(what); 
        
        
    }
    
    
    


}

view.dsiplay();


