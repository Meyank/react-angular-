import React from 'react';
import axios from 'axios';
class BadgeForm extends React.Component{
 
    state={
        userName:""
    }

    updateUser=(event)=>{
      
       this.setState({
       userName : event.target.value
        }  );

     
       

    }

handleSubmit=(event)=>{
    event.preventDefault();
    console.log(this.state.userName);

//     fetch(`https://api.github.com/users/${this.state.userName}`)
//     .then(function(response){
//   console.log(response.json());
//     });

axios.get(`https://api.github.com/users/${this.state.userName}`)
.then( res=>{
 
    data:this.props.onSubmit(res.data);

      console.log(res);
        });
}

render(){
    return(
<div style={{marginTop:'2em',marginLeft:'2em'}}>
<form onSubmit={this.handleSubmit}>

    <input type="text" placeholder="Github username" onChange={this.updateUser}/>
    
    {/* ref={(input)=>{ this.usernameText = input;}}/> */}

    <input type="submit" value="add"/>
</form>

</div>
    );
}


} 
export default BadgeForm;