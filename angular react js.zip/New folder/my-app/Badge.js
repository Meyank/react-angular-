import React from 'react';

const Badge = (props)=>{
    
    return(
    <div className="container" style={{border:'1px solid black',width:'20em' ,marginLeft:'5%',marginTop:'5%'}}>
        <img style={{marginLeft:'1em',marginTop:'2em'}} width="75" height="75" src={props.avatar_url}/>
        <div className="details" style={{display:'inline-block',fontFamily:'cursive',fontSize:'1.5em',marginLeft:'15%',marginBottom:'15%'}} >
        <div>{props.name}</div>
        <div>{props.company}</div>
        </div>
        </div>
    
    );
    
}
export default Badge;