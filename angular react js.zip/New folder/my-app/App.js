import React from 'react';
import BadgeList from './BadgeList';
import BadgeForm from './BadgeForm';

class App extends React.Component{



    state={
                data:[
                   { avatar_url:"https://avatars3.githubusercontent.com/u/34234918?v=4",
                name:"Mayank" ,
                company:"yash technology"
          
                },
               
                {
                    avatar_url:"https://avatars2.githubusercontent.com/u/79884?v=4" ,
                    name:"Ishan", 
                    company:"yash technology" 
                }
            ]
        }
        updateState=(badgeInfo)=>{
           this.setState( {
               data :this.state.data.concat(badgeInfo)
            }
        );
        }

    render(){
 
        return(
           <div> 
            <BadgeForm onSubmit={this.updateState}/>
            <BadgeList badges={this.state.data}/>
            </div>
        );
    }
}

export default App;