import React from 'react';
import Badge from './Badge';

// class BadgeList extends React.Component{

//     state={
//         data:[
//            { avatar_url:"https://avatars3.githubusercontent.com/u/34234918?v=4",
//         name:"Mayank" ,
//         company:"yash technology"
  
//         },
       
//         {
//             avatar_url:"https://avatars2.githubusercontent.com/u/79884?v=4" ,
//             name:"Ishan", 
//             company:"yash technology" 
//         }
//     ]
// }
// render(){
//     return(
//     <div>
//         {this.state.data.map(badge =>
//             <Badge {...badge}/>
//         )}
//     </div>

//     );
// }





// const BadgeList = (props) => {


//     return(
//     <div>
//         <Badge avatar_url="https://avatars3.githubusercontent.com/u/34234918?v=4"
//          name="Mayank" company="yash technology"/>
//         <Badge  avatar_url="https://avatars2.githubusercontent.com/u/79884?v=4" 
//         name="Ishan" company="yash technology"/>
//         </div>
//     );
// }


const BadgeList = (props) => {


    return(
    <div>
       {props.badges.map(badge=>
    <Badge {...badge} key={badge.name}/>
    )}
        </div>
    );
}
export default BadgeList;