var newPassword = document.getElementById("newPassword");
window.alert(newPassword);

function matchNewPassword() {
	var newPassword = document.getElementById("newPassword");
	var confirmPassword = document.getElementById("confirmPassword");
	if (newPassword != confirmPassword) {
		alert("New Password entered didn't match..Try again buddy........")
	}
}