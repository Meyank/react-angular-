import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import {Http, Headers, Response} from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class ListquestionsService {
  
/**
 * injected http herer
 * @param http 
 */
  constructor(private http:Http) { }

/**
 * this will send the userid to backend and recieve the lists 
 * @param userid 
 */

  getQuestions(userid:Number): Observable<Object[]>{
    
           let url = "http://localhost:8080/userfrontweb/question/"+userid;
         return this.http.get(url).map(this.extractData);
    
      }
      
      private extractData(res: Response) {
        
        let body = res.json();
        
        
              return body;
          }


}

