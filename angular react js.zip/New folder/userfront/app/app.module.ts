import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {MatButtonModule, MatCheckboxModule} from '@angular/material';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AppRoutingModule } from './/app-routing.module';
import { AddquestionComponent } from './addquestion/addquestion.component';
import {FormsModule} from '@angular/forms';
import { HttpModule } from '@angular/http';
import {AddquestionService} from './addquestion.service';
import {ListquestionsService} from './listquestions.service';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    AddquestionComponent,
    
  ],
  imports: [
    BrowserModule,
	BrowserAnimationsModule,
  MatButtonModule, 
  MatCheckboxModule, 
  AppRoutingModule,
  FormsModule,
  HttpModule
  ],
  providers: [AddquestionService,ListquestionsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
