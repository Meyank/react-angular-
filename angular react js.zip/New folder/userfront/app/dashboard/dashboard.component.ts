import { Component, OnInit } from '@angular/core';
import { Router,RouterStateSnapshot} from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { ActivatedRoute,ParamMap,ActivatedRouteSnapshot} from '@angular/router';
import {ListquestionsService} from '../listquestions.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  
/**
 * userid to be obtained from userserice once logged in user is here
 */
  userid:Number=1;
/**
 * this is to hold the question from response
 */
  questions : Object[];
  constructor(private activatedRoute: ActivatedRoute,private router: Router,private questionService:ListquestionsService) { }

 



  public sub: Observable<string>;
  public success : string;    
  ngOnInit() {
    /** this logic is to give the msg after successfull addition of question*/
     this.success = this.activatedRoute.snapshot.queryParamMap.get('success');
     
    
  }

/**
 * to get all the question saved in db this will call a method of listquestionservice which will
 * connenct with server and retrieve the data.
 */
  getQuestions(){
    console.log(this.userid);
    this.success = null;
   this.questionService.getQuestions(this.userid).subscribe(
      
    question =>this.questions=question 
     
   );
 }


}
