import { Component, OnInit } from '@angular/core';
import {AddquestionService} from '../addquestion.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addquestion',
  templateUrl: './addquestion.component.html',
  styleUrls: ['./addquestion.component.css']
})
export class AddquestionComponent implements OnInit {

/**this is an placeholder for travelling the question  */
  question:string;

  /**user id will be generated from userservice once logged in user will be here */
userid:Number=1;
/**
 * here i have injected two services 
 * @param router 
 * @param addQuestionService 
 */
  constructor(private router: Router,private addQuestionService: AddquestionService) { }

  


  ngOnInit() {
  }

/**
 * this mehtod will pass the enterd question and userid of the user to service send questrion method
 * which will pass thes further 
 * here userid can be changed once user is logged in as login service will provide me the userid
 */
  onSubmit(){
    
    this.addQuestionService.sendquestion(this.question,this.userid).subscribe(
      
      res => {
        console.log(res);
       
        this.router.navigate(['/dashboard'],{ queryParams: { success: true}});
         
      },
      err =>
      {
        console.log(err);
      }  );
    
}
}

