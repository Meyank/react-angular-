import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import {Http, Headers, Response} from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class AddquestionService {

  /**
   * http injected here
   * @param http 
   */
  constructor(private http:Http) { }




  sendquestion(question: string, userid: Number) {
    /**
     * url to the backend controller handler method
     */
     let url = 'http://localhost:8080/userfrontweb/question';

     //**preparing json */
  var data={ "question":question,"userid":userid,"createdBy":userid };
  /**setting header in response 
   * above two things header and url preparation can be done by defining a 
   * constant above in case there are many methods which are 
   * gonna use url and header
   */
  let headers = new Headers(
  {  
    'Content-Type': 'application/json'
   });
 
  return this.http.post(url, data, {headers: headers, withCredentials : true});
}
}
