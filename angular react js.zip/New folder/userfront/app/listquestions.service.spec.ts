import { TestBed, inject } from '@angular/core/testing';

import { ListquestionsService } from './listquestions.service';

describe('ListquestionsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ListquestionsService]
    });
  });

  it('should be created', inject([ListquestionsService], (service: ListquestionsService) => {
    expect(service).toBeTruthy();
  }));
});
